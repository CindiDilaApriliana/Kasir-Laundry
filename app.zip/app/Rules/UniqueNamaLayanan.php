<?php

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use App\Models\Layanan;

class UniqueNamaLayanan implements Rule
{
    protected $currentId;

    public function __construct($currentId = null)
    {
        $this->currentId = $currentId;
    }

    public function passes($attribute, $value)
    {
        // Check for uniqueness, excluding the current record in edit mode
        return Layanan::where('nama_layanan', $value)
            ->when($this->currentId, function ($query) {
                $query->where('id', '!=', $this->currentId);
            })
            ->count() === 0;
    }

    public function message()
    {
        return 'The :attribute has already been taken.';
    }
}
