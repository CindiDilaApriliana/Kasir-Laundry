<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model

{
    use HasFactory;
    protected $table = 'transaksis';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id', 'nama', 'layanan_id', 'berat', 'no_hp', 'status', 'pembayaran', 'tanggal_masuk', 'tanggal_keluar'
    ];

    public function layananlaundry()
    {
        return $this->belongsTo(Layanan::class);
    }
    public function layanan()
    {
        return $this->hasMany(\App\Models\Layanan::class, 'id', 'layanan_id');
    }
    public function layanans()
    {
        return $this->hasMany(Layanan::class);
    }
}
