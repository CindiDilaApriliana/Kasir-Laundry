<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LaporanTransaksi extends Model
{
    use HasFactory;

    protected $fillable = [
        'id', 'nama', 'layanan_id', 'berat', 'panjang', 'total', 'no_hp', 'status', 'pembayaran', 'tanggal_masuk', 'tanggal_keluar',
    ];
}
