<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Laundry extends Model
{
    use HasFactory;
    protected $table = 'datalaundrys';
    protected $primaryKey = 'id';
    protected $fillable = [
        'id', 'nama_laundry', 'alamat', 'telp',
    ];
}
