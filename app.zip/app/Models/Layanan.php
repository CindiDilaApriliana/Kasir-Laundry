<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Layanan extends Model
{
    protected $table = 'layanans';
    protected $primaryKey = 'id';
    protected $fillable = ['id', 'nama_layanan', 'harga'];

    public function transaksi()
    {
        return $this->hasMany(Transaksi::class);
    }

    public function layanans()
    {
        return $this->hasMany(Layanan::class, 'transaksi_id', 'id');
    }
}
