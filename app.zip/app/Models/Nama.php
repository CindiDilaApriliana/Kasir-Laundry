<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

// app/Models/Nama.php
class Nama extends Model
{
    protected $table = 'nama_table'; // Replace with your actual table name

    // Define your model attributes, relationships, and other configurations here
}
