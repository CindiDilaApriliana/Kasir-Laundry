<?php

// app/Http/Middleware/EmployeeMiddleware.php

// app/Http/Middleware/EmployeeMiddleware.php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class EmployeeMiddleware
{
    public function handle($request, Closure $next)
    {
        if (Auth::check() && Auth::user()->role == 'pegawai') {
            return $next($request);
        }

        return redirect('/home'); // Redirect to the home page if not an employee
    }
}
