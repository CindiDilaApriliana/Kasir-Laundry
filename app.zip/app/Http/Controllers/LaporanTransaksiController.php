<?php

namespace App\Http\Controllers;

use App\Models\LaporanTransaksi;
use App\Models\Layanan;
use App\Models\Transaksi;
use Barryvdh\DomPDF\PDF;
use Illuminate\Http\Request;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;



class LaporanTransaksiController extends Controller
{
    public function getTransaksi()
    {
        $data = Transaksi::paginate(10);

        foreach ($data as $dt) {
            $listLayanan = [];
            $layananId = explode(',', $dt->layanan_id);
            for ($i = 0; $i < count($layananId); $i++) {
                $dataLayanan = Layanan::where('id', $layananId[$i])->first();
                // dd($dataLayanan);
                array_push($listLayanan, $dataLayanan);
            }

            $dt->layanan_id = $listLayanan;
        }

        // $data = Transaksi::paginate(10);
        // $data = Transaksi::with('layananlaundry')->paginate(10);
        return view('laporantransaksi', [
            'data' => $data
        ]);
    }
    // public function show()
    // {
    //     return view('laporan transaksi.laporantransaksipdf', [
    //         'data' => Transaksi::all()
    //     ]);
    // }



    public function printPDF(Request $request)
    {
        //         if ($request->ajax()) {
        //             $tanggal_awal = $request->tanggal_awal;
        //             $tanggal_akhir = $request->tanggal_akhir;

        //             $query = Transaksi::query();

        //             if (isset($tanggal_awal) && isset($tanggal_akhir)) {
        //                 $query->whereBetween('tanggal_masuk', [
        //                     date('Y-m-d', strtotime($tanggal_awal)),
        //                     date('Y-m-d', strtotime($tanggal_akhir))
        //                 ]);
        //             }

        //             $data = $query->orderBy('id', 'desc')->get();

        //             return DataTables::of($data)
        //                 ->addIndexColumn()
        //                 ->addColumn('action', function ($row) {
        //                     return "<a href='" . url('transaksi') . "/$row->id' class='btn btn-primary btn-sm'>Lihat Detail</a>";
        //                 })
        //                 ->addColumn('tanggal_formated', function ($row) {
        //                     return date('d F Y', strtotime($row->tanggal_masuk));
        //                 })
        //                 ->rawColumns(['action'])
        //                 ->make(true);
        //         }

        //         return view('laporan transaksi.laporantransaksipdf');
        //     }
        // }

        $tanggal1 = $request->tanggal1;
        $tanggal2 = $request->tanggal2;

        if ($tanggal1 && $tanggal2) {
            $data = Transaksi::whereBetween('tanggal_masuk', [$tanggal1, $tanggal2])->get();
            $title = 'Laporan Barang Masuk';
            $date = date('j F Y', strtotime($tanggal1));
            $date2 = date('j F Y', strtotime($tanggal2));
        } elseif ($tanggal1) {
            $dateNow = Carbon::now();
            $data = Transaksi::whereBetween('tanggal_masuk', [$tanggal1, $dateNow])->get();
            $title = 'Laporan Barang Masuk';
            $date = date('j F Y', strtotime($tanggal1));
            $date2 = date('j F Y', strtotime($dateNow));
        } else {
            $data = Transaksi::all();
            $title = 'Laporan Barang Masuk';
            $date = '';
            $date2 = '';
        }

        // $pdf = PDF::loadView('laporan transaksi.laporantransaksipdf', compact('data', 'title', 'date', 'date2'));
        $pdf = app('dompdf.wrapper');
        $pdf->loadView('laporantransaksi.laporantransaksipdf', compact('data', 'title', 'date', 'date2'));

        return $pdf->stream('Laporan Barang Masuk.pdf');
    }
}
