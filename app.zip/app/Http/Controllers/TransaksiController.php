<?php

namespace App\Http\Controllers;

use App\Models\Layanan;
use App\Models\Nama;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Faker\Guesser\Name;
use GuzzleHttp\Psr7\Response;
use Illuminate\Pagination\LengthAwarePaginator;
use Laracasts\Flash\Flash;
use Illuminate\Database\Eloquent\Collection;

class TransaksiController extends Controller
{

    // Show the form to add new data
    public function showForm()
    {
        return view('tambahdata');
    }


    // Add new data to the database
    public function addData(Request $request)
    {
        $formField = $request->validate([
            'nama' => 'required|string',
            'no_hp' => 'required',
            'status' => 'required',
            'pembayaran' => 'required',
            'tanggal_masuk' => 'required',
            'tanggal_keluar' => 'required',
        ]);

        // dd($request->all());
        $count = 1;
        $layanan = [];
        $berat = [];
        while (isset($request['layanan' . $count]) && isset($request['berat' . $count])) {
            $layanan[] = $request['layanan' . $count];
            $berat[] = $request['berat' . $count];
            $count++;
        }
        $formField['layanan'] = $layanan;
        $formField['brt'] = $berat;

        // dd($formField);
        // Validate the form data

        foreach ($layanan as $l) {
            $formField['layanan_id'] = implode(',', $formField['layanan']);
            $formField['berat'] = implode(',', $formField['brt']);
        }

        // Create a new Transaksi instance and save to the database
        Transaksi::create($formField);

        // Redirect to the data list page
        return redirect('/admin/datatransaksi')->with('success', 'Data Transaksi berhasil diperbarui.');
    }

    // Display the list of transactions
    // Display the list of transactions
    // Display the list of transactions
    public function getTransaksi()
    {
        // Menggunakan paginate(10) untuk membatasi jumlah item per halaman
        $data = Transaksi::paginate(10);

        foreach ($data as $dt) {
            $listLayanan = [];
            $layananId = explode(',', $dt->layanan_id);
            for ($i = 0; $i < count($layananId); $i++) {
                $dataLayanan = Layanan::where('id', $layananId[$i])->first();
                // dd($dataLayanan);
                array_push($listLayanan, $dataLayanan);
            }

            $dt->layanan_id = $listLayanan;
        }

        return view('datatransaksi', [
            'data' => $data
        ]);
    }



    // Show the form to edit an existing data
    public function editdatatransaksi($id)
    {
        $transaksi = Transaksi::find($id);

        $listLayanan = [];
        $layananId = explode(',', $transaksi->layanan_id);
        for ($i = 0; $i < count($layananId); $i++) {
            $dataLayanan = Layanan::where('id', $layananId[$i])->first();
            // dd($dataLayanan);
            array_push($listLayanan, $dataLayanan);
        }

        $listBerat = [];
        $berat = explode(',', $transaksi->berat);

        $transaksi->berat = $berat;
        $transaksi->layanan_id = $listLayanan;

        return view('transaksi.editdatatransaksi', compact('transaksi'));
    }


    // Update an existing data
    // Update an existing data
    public function editdata(Request $request, $id)
    {
        $transaksi = Transaksi::find($id);

        $request->validate([
            'nama' => 'required|string',
            'layanan_id' => 'required|array',
            'berat' => 'required|array',
            'no_hp' => 'required|numeric',
            'status' => 'required|string|in:Proses,Selesai',
            'pembayaran' => 'required|string|in:Belum Bayar,Lunas',
            'tanggal_masuk' => 'required|date',
            'tanggal_keluar' => 'required|date',
        ]);

        // Update the data in the database
        $transaksi = Transaksi::findOrFail($id);
        $transaksi->nama = $request->input('nama');
        $transaksi->layanan_id = implode(',', $request->layanan_id);
        $transaksi->berat = implode(',', $request->berat);
        $transaksi->no_hp = $request->input('no_hp');
        $transaksi->status = $request->input('status');
        $transaksi->pembayaran = $request->input('pembayaran');
        $transaksi->tanggal_masuk = $request->input('tanggal_masuk');
        $transaksi->tanggal_keluar = $request->input('tanggal_keluar');
        $transaksi->save();


        // Redirect to the data listing page
        return redirect('admin/datatransaksi')->with('success', 'Data Transaksi berhasil diperbarui.');
    }


    // Delete an existing data
    public function deleteTransaksi($id)
    {
        Transaksi::destroy($id);
        return redirect('/admin/datatransaksi')->with('success', 'Data Transaksi berhasil dihapus.');
    }

    // public function deleteData($id)
    // {
    //     $ly = Layanan::where('id', $id)->first();
    //     $ly->delete();
    //     return back();
    // }

    public function status($id)
    {
        Transaksi::where('id', $id)->update([
            'status' => 'Selesai'
        ]);

        Flash::success('Status Transaksi berhasil diubah.');
        return back();
    }
    public function status_pembayaran($id)
    {
        Transaksi::where('id', $id)->update([
            'pembayaran' => 'Lunas'
        ]);

        return back()->with('success', 'Transaksi sudah di bayar lunas .');
    }

    // app/Http/Controllers/TransaksiController.php

    // app/Http/Controllers/TransaksiController.php

    public function filter(Request $request)
    {
        $startDate = $request->input('tanggal_awal');
        $endDate = $request->input('tanggal_akhir');
        $search = $request->input('search');

        $data = Transaksi::with('layanan')
            ->where('nama', 'like', '%' . $search . '%')
            ->orWhereHas('layanan', function ($query) use ($search) {
                $query->where('nama_layanan', 'like', '%' . $search . '%');
            })
            ->orWhere('id', '=', $search)
            ->orWhere('berat', 'like', '%' . $search . '%')
            ->orWhere('status', 'like', '%' . $search . '%')
            ->orWhere('pembayaran', 'like', '%' . $search . '%')
            ->orWhere('tanggal_masuk', 'like', '%' . $search . '%')
            ->orWhere('tanggal_keluar', 'like', '%' . $search . '%')
            ->whereBetween('tanggal_masuk', [$startDate, $endDate])
            ->orWhereBetween('tanggal_keluar', [$startDate, $endDate])
            ->paginate(10);

        foreach ($data as $dt) {
            $listLayanan = [];
            $layananId = explode(',', $dt->layanan_id);
            $total = 0;

            for ($i = 0; $i < count($layananId); $i++) {
                $dataLayanan = Layanan::where('id', $layananId[$i])->first();
                array_push($listLayanan, $dataLayanan);

                // Assuming 'harga' is the price field in your Layanan model
                $harga = floatval($dataLayanan->harga); // Convert to float
                $berat = floatval($dt->berat[$i]); // Convert to float

                $total += $harga * $berat;
            }

            $dt->layanan_id = $listLayanan;
            $dt->total = $total;
        }

        return view('datatransaksi', compact('data'));
    }




    public function searchMember(Request $request)
    {
        $nama = $request->input('nama');

        // Cari member berdasarkan nama
        $data = Transaksi::where('nama', 'like', '%' . $nama . '%')->get();

        return response()->json($data);
    }
}
