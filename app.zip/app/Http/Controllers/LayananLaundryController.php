<?php

namespace App\Http\Controllers;

use App\Rules\UniqueNamaLayanan;

use Illuminate\Http\Request;
use App\Models\Layanan;

class LayananLaundryController extends Controller
{
    public function getLayanan()
    {
        $data = Layanan::paginate(10);
        return view('datalayanan', compact('data'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_layanan' => [
                'required',
                'string',
                'max:200',
                new UniqueNamaLayanan,
            ],
            'harga' => 'required|numeric',
        ]);

        Layanan::create([
            'nama_layanan' => $request->input('nama_layanan'),
            'harga' => $request->input('harga'),
        ]);

        return redirect('/datalayanan')->with('success', 'Layanan berhasil ditambahkan.');
    }

    public function editlayanan($id)
    {
        $layanan = Layanan::findOrFail($id);
        return view('layanan.editlayanan', compact('layanan'));
    }

    public function edit(Request $request, $id)
    {
        $layanan = Layanan::findOrFail($id);

        $request->validate([
            'nama_layanan' => [
                'required',
                'string',
                'max:200',
                new UniqueNamaLayanan($id), // Pass the $id to ignore current record in edit mode
            ],
            'harga' => 'required|numeric',
        ]);

        $layanan->update([
            'nama_layanan' => $request->input('nama_layanan'),
            'harga' => $request->input('harga'),
        ]);

        return redirect('datalayanan')->with('success', 'Layanan berhasil diperbarui.');
    }

    public function deletedata($id)
    {
        Layanan::destroy($id);
        return redirect('/datalayanan')->with('success', 'Layanan berhasil dihapus.');
    }
}
