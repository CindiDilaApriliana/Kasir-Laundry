<?php

namespace App\Http\Controllers;

use App\Models\Laundry;
use Illuminate\Http\Request;

class DataLaundryController extends Controller
{
    public function index()
    {
        $laundry = Laundry::all();
        return view('datalaundry', compact('laundry'));
    }

    public function editdatalaundry($id)
    {
        $laundry = Laundry::findOrFail($id);
        return view('laundry/editdatalaundry', compact('laundry'));
    }

    public function editlaundry(Request $request, $id)
    {
        $request->validate([
            'nama_laundry' => 'required|string|max:200',
            'alamat' => 'required|string|max:200',
            'telp' => 'required|numeric',
        ]);

        $laundry = Laundry::findOrFail($id);
        $laundry->update([
            'nama_laundry' => $request->input('nama_laundry'),
            'alamat' => $request->input('alamat'),
            'telp' => $request->input('telp'),
        ]);

        return redirect('datalaundry')->with('success', 'Data laundry berhasil diperbarui.');
    }
}
