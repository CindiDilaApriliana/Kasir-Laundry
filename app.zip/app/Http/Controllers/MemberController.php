<?php

namespace App\Http\Controllers;

use App\Models\Member;
use Illuminate\Http\Request;

class MemberController extends Controller
{



    public function addMember(Request $request)
    {
        // Validate the request
        $request->validate([
            'nama' => 'required|string',
            'no_hp' => 'required|string',
            // ... (other validation rules)
        ]);

        // Create a new member in the database
        Member::create([
            'nama' => $request->input('nama'),
            'no_hp' => $request->input('no_hp'),
            // ... (other fields)
        ]);

        // Rest of your store logic

        return redirect('datatransaksi')->with('success', 'Data transaksi berhasil ditambahkan.');
    }

    public function searchMember(Request $request)
    {
        $nama = $request->input('nama');

        // Cari member berdasarkan nama
        $data = Member::where('nama', 'like', '%' . $nama . '%')->get();

        return response()->json($data);
    }
}
