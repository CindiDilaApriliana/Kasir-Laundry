<?php

// App/Http/Controllers/PegawaiController.php

namespace App\Http\Controllers;

class PegawaiController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }
}
