<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function generateInvoice($id)
    {
        // Fetch the transaction data from the database using the $id
        $transaksi = Transaksi::find($id);

        // Check if the transaction exists
        if (!$transaksi) {
            abort(404); // Or handle it in a way suitable for your application
        }

        // Split the layanan_id string into an array
        $layananIds = explode(', ', $transaksi->layanan_id);

        // Fetch layanan data from the database using the layananIds
        $layanans = \App\Models\Layanan::whereIn('id', $layananIds)->get();
        return view('notatransaksi', [
            'transaksi' => $transaksi,
            'layanans' => $layanans,
        ]);
    }
}
