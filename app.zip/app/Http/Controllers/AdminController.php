<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Session;
use App\Models\Transaksi; // Sesuaikan dengan namespace dan model yang sebenarnya
use App\Models\Layanan; // Sesuaikan dengan namespace dan model yang sebenarnya
use App\Models\Laundry; // Sesuaikan dengan namespace dan model yang sebenarnya

class AdminController extends Controller
{
    public function shareDataToPegawai()
    {
        // Ambil data yang ingin dibagikan
        $data = [
            'transaksi' => Transaksi::all(),
            'laporantransaksi' => Transaksi::all(), // Ganti dengan model yang benar jika perlu
            'layanan' => Layanan::all(),
            'laundry' => Laundry::all(),
            // tambahkan data lainnya yang ingin dibagikan
        ];

        // Simpan data dalam session
        Session::put('pegawai_data', $data);

        return redirect('/pegawai/dashboard');
    }
}
