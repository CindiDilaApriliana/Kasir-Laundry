<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use App\Models\LaporanTransaksi;
use App\Models\Laundry;
use App\Models\Layanan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function dashboard()
    {
        $dataTransaksiCount = Transaksi::count();
        $laporanTransaksiCount = Transaksi::count();
        $dataLaundryCount = Laundry::count();
        $dataLayanaCount = Layanan::count();

        return view('admin.dashboard', compact('dataTransaksiCount', 'laporanTransaksiCount', 'dataLaundryCount', 'dataLayanaCount'));
    }

    public function index()
    {
        Auth::user()->name;
        return view('index');
    }

    public function pegawai()
    {
        Auth::user()->name;
        return view('index');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->route('login'); // Sesuaikan dengan rute halaman login Anda
    }

    public function datatransaksi()
    {
        return view('datatransaksi');
    }
}
