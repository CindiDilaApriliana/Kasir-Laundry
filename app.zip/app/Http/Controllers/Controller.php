<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;

class Controller extends BaseController
{
    public function dashboard()
    {
        return view('admin/dashboard');
    }
    public function index()
    {
        return view('index', compact('data'));
    }

    public function datatransaksi()
    {
        return view('admin/datatransaksi');
    }

    public function laporantransaksi()
    {
        return view('admin/laporantransaksi');
    }
}
