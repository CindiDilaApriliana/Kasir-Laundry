<div class="modal fade" id="modalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
              <div class="modal-body">
                <form id="dataForm" action="/datatransaksi" method="POST">
                
                      @csrf 
                      {{-- <div class="form-group">
                          <label>Nama</label>
                          <input type="text" name="nama" class="form-control">
                      </div> --}}
                      <div class="form-group">
                        <label>Nama </label>
                        <input type="text" name="nama" class="form-control" oninput="searchMember()">
                    </div>
                    <div id="searchResults"></div>
                    
                    <div class="form-group">
                        <label>No.HP</label>
                        <input type="text" name="no_hp" class="form-control" oninput="validatePhoneNumber(this)">
                    </div>
                      <div id="dynamic-selects">
                        <label>Jenis Layanan<label>
                        <!-- Dynamic select inputs will be added here -->
                    </div>
                    <button type="button" class="btn btn-primary" onclick="addSelect()">Tambah Layanan</button>
                    
                      <div class="form-group">
                          <label>Status</label>
                          <select name="status" class="form-select" aria-label="Default select example">
                              <option selected>Selesai</option>
                              <option selected="1">Proses</option>
                          </select>
                      </div>
                      <div class="form-group">
                          <label>Pembayaran</label>
                          <select name="pembayaran" class="form-select" aria-label="Default select example">
                              <option selected>Lunas</option>
                              <option selected="1">Belum Bayar</option>
                          </select>
                      </div>
                     <div class="form-group">
    <label>Tanggal Masuk</label>
    <input type="text" name="tanggal_masuk" class="form-control" id="tanggal_masuk">
</div>

<div class="form-group">
    <label>Tanggal Keluar</label>
    <input type="text" name="tanggal_keluar" class="form-control" id="tanggal_keluar">
</div>
                      <div class="modal-footer">
                          <button type="submit" class="btn btn-primary">Tambah Data</button>
                      </div>
                  </form>
              </div>
        </div>
    </div>
  </div>
  <script>
   var count = 0;

function addSelect() {
    count += 1;
    var dynamicSelectsContainer = document.getElementById('dynamic-selects');

    var divElement = document.createElement('div');
    divElement.id = 'input' + count;
    divElement.className = 'd-flex align-items-center mb-2';

    // Create select element and populate options from Layanan model
    var selectElement = document.createElement('select');
    selectElement.name = 'layanan' + count;
    selectElement.className = 'form-control w-25';

    // Replace the placeholder values with your actual data from Layanan model
    @foreach(\App\Models\Layanan::all() as $layanan)
        var optionElement = document.createElement('option');
        optionElement.value = '{{ $layanan->id }}';
        optionElement.text = '{{ $layanan->nama_layanan }}';
        selectElement.appendChild(optionElement);
    @endforeach

    var beratInput = document.createElement('input');
    beratInput.name = 'berat' + count; // Change to an array to allow multiple weights
    beratInput.className = 'form-control w-25 mx-2';
    beratInput.type = 'number';
    beratInput.oninput = validateBerat;

    var removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'btn btn-danger';
    removeButton.textContent = 'Hapus';
    removeButton.onclick = function () {
        dynamicSelectsContainer.removeChild(divElement);
    };

    divElement.appendChild(selectElement);
    divElement.appendChild(beratInput);
    divElement.appendChild(removeButton);

    dynamicSelectsContainer.appendChild(divElement);

        function validateBerat() {
            var value = parseFloat(beratInput.value);
            if (value <= 0 || Math.floor(value) !== parseFloat(value)) {
                beratInput.value = '';
            }
        }
    }
        // ... (your existing script)

        
</script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

<script>
    // ... (your existing script)

    function searchMember() {
        var inputNama = document.getElementsByName('nama')[0].value;
        var searchResultsContainer = document.getElementById('searchResults');

        // Clear previous search results
        searchResultsContainer.innerHTML = '';

        // Perform Ajax request to search for member by name
        $.ajax({
            type: 'GET',
            url: '/searchmember?nama=' + inputNama,
            success: function (data) {
                // Display search results
                if (data.length > 0) {
                    // Display only the first result
                    var listItem = document.createElement('li');
                    listItem.textContent = data[0].nama + ' - ' + data[0].no_hp;
                    listItem.onclick = function () {
                        // Set selected member's name and phone number in the form
                        document.getElementsByName('nama')[0].value = data[0].nama;
                        document.getElementsByName('no_hp')[0].value = data[0].no_hp;

                        // Clear search results
                        searchResultsContainer.innerHTML = '';

                        // Automatically trigger the input event to execute the oninput function for 'no_hp'
                        var event = new Event('input', { bubbles: true });
                        document.getElementsByName('no_hp')[0].dispatchEvent(event);
                    };

                    // Clear search results container before appending the new result
                    searchResultsContainer.innerHTML = '';
                    searchResultsContainer.appendChild(listItem);
                } else {
                    // Display message if no results found
                    searchResultsContainer.innerHTML = '<p>Nama Belum Ada</p>';
                }
            }
        });
    }
</script>
<script>
    $(document).ready(function () {
        $('#tanggal_masuk').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
            todayHighlight: true,
            startDate: new Date()
        });

        $('#tanggal_keluar').datepicker({
            format: 'dd-mm-yyyy',
            autoclose: true,
            todayHighlight: true,
            startDate: new Date()
        });

        // Add this script to handle the date formatting before form submission
        $('#dataForm').submit(function (e) {
            // Prevent the form from submitting immediately
            e.preventDefault();

            // Format the tanggal_masuk and tanggal_keluar values using PHP-like formatting
            var tanggalMasuk = $('#tanggal_masuk').datepicker('getDate');
            var formattedTanggalMasuk = formatDateForMySQL(tanggalMasuk);
            $('#tanggal_masuk').val(formattedTanggalMasuk);

            var tanggalKeluar = $('#tanggal_keluar').datepicker('getDate');
            var formattedTanggalKeluar = formatDateForMySQL(tanggalKeluar);
            $('#tanggal_keluar').val(formattedTanggalKeluar);

            // Now, submit the form
            this.submit();
        });

        // Helper function to format date for MySQL
        function formatDateForMySQL(date) {
            var day = ("0" + date.getDate()).slice(-2);
            var month = ("0" + (date.getMonth() + 1)).slice(-2);
            var year = date.getFullYear();
            return year + "-" + month + "-" + day;
        }
    });
</script>
<script>
    // ... (your existing script)

    function validatePhoneNumber(inputElement) {
        // Remove non-numeric characters from the input value
        var sanitizedValue = inputElement.value.replace(/\D/g, '');

        // Update the input value with the sanitized value
        inputElement.value = sanitizedValue;
    }
    

    // ... (your existing script)
</script>