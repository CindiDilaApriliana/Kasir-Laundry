@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Edit Data Transaksi</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="modal-body">
        <div class="d-sm-flex justify-content-between align-items-center">
            <div class="table-responsive">
<form action="{{ url('transaksi/editdata', $transaksi->id) }}" method="POST">

                    @method('PUT')
                    @csrf
            <div class="form-group">
                <div class="form-group">
                    <label>Nama</label>
                    <input type="text" name="nama" class="form-control" value="{{ $transaksi->nama}}">
                </div>
                {{-- <div class="ml-4 form-check d-flex flex-column">
                  @foreach(\App\Models\Layanan::all() as $layanan)
                      <div>
                          <input class="form-check-input" type="checkbox" name="layanan_id[]" value="{{ $layanan->id }}" id="flexCheck{{ $layanan->id }}">
                          <label class="form-check-label" for="flexCheck{{ $layanan->id }}">{{ $layanan->nama_layanan }}</label>
                      </div>
                  @endforeach
              </div>
      
                <div class="form-group">
                    <label>Berat</label>
                    <input type="number" name="berat" class="form-control">
                </div> --}}
                <div id="dynamic-selects">
                    @foreach($transaksi->layanan_id as $key => $layanan)
                        <div class="d-flex align-items-center mb-2" id="input{{ $loop->index + 1 }}">
                            <select name="layanan_id[]" class="form-control w-25">
                                @foreach(\App\Models\Layanan::all() as $ly)
                                    <option value="{{ $ly->id }}"
                                            {{ $ly->id == $layanan->id ? 'selected' : '' }}>
                                        {{ $ly->nama_layanan }}
                                    </option>
                                @endforeach
                            </select>
                            <input type="number" name="berat[]" class="form-control w-25 mx-2" value="{{ $transaksi->berat[$key] }}" oninput="validateBerat(this)">
                            @if (\App\Models\Layanan::all()->count() > 1)
                                <button type="button" class="btn btn-danger" onclick="removeSelect({{ $loop->index + 1 }})">Hapus</button>
                            @endif
                        </div>
                    @endforeach
                </div>
                <button type="button" class="btn btn-primary" onclick="addSelect()">Tambah Select</button>
                
            <div class="form-group">
                <label>No.HP</label>
                <input type="integer" name="no_hp" class="form-control" value="{{ $transaksi->no_hp }}">
            </div>

            <div class="form-group">
                <label>pembayaran</label>
                <select name="status" class="form-select" aria-label="Default select example">
                    <option value="Proses" {{ $transaksi->status == 'Proses' ? 'selected' : '' }}>Proses</option>
                    <option value="Selesai" {{ $transaksi->status == 'Selesai' ? 'selected' : '' }}>Selesai</option>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="pembayaran" class="form-select" aria-label="Default select example">
                    <option value=" Belum Bayar" {{ $transaksi->pembayaran == 'Belum Bayar' ? 'selected' : '' }}>Belum Bayar</option>
                    <option value="Lunas" {{ $transaksi->pembayaran == 'Lunas' ? 'selected' : '' }}>Lunas</option>
                </select>
            </div>

            <div class="form-group">
                <label>Tanggal Masuk</label>
                <input type="date" name="tanggal_masuk" class="form-control" value="{{ $transaksi->tanggal_masuk }}">
            </div>

            <div class="form-group">
                <label>Tanggal Keluar</label>
                <input type="date" name="tanggal_keluar" class="form-control" value="{{ $transaksi->tanggal_keluar }}">
            </div>

            <div class="modal-footer">
                <a href="{{ route('datatransaksi') }}" class="btn btn-secondary">Close</a>
                <button type="submit" class="btn btn-primary">Edit</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>
<script>
    var count = 0;

    function addSelect() {
        count += 1;
        var dynamicSelectsContainer = document.getElementById('dynamic-selects');

        var divElement = document.createElement('div');
        divElement.id = 'input' + count;
        divElement.className = 'd-flex align-items-center mb-2';

        var selectElement = document.createElement('select');
        selectElement.name = 'layanan_id[]';
        selectElement.className = 'form-control w-25';

        @foreach(\App\Models\Layanan::all() as $layanan)
            var optionElement = document.createElement('option');
            optionElement.value = '{{ $layanan->id }}';
            optionElement.text = '{{ $layanan->nama_layanan }}';
            selectElement.appendChild(optionElement);
        @endforeach

        var beratInput = document.createElement('input');
        beratInput.name = 'berat[]'; 
        beratInput.className = 'form-control w-25 mx-2';
        beratInput.type = 'number';
        beratInput.value = ''; // Set default value to empty

        var removeButton = document.createElement('button');
        removeButton.type = 'button';
        removeButton.className = 'btn btn-danger';
        removeButton.textContent = 'Hapus';
        removeButton.onclick = function () {
            dynamicSelectsContainer.removeChild(divElement);
        };

        divElement.appendChild(selectElement);
        divElement.appendChild(beratInput);
        divElement.appendChild(removeButton);

        dynamicSelectsContainer.appendChild(divElement);
    }
</script>
<script>
    function validateBerat(inputElement) {
        var value = inputElement.value;
        // Menghapus karakter non-numeric dari nilai input
        var sanitizedValue = value.replace(/\D/g, '');

        // Update nilai input dengan nilai yang telah disaring
        inputElement.value = sanitizedValue;
    }
</script>
@endsection