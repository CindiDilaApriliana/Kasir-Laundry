@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Laporan Transaksi</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <div class="my-3">
                <form action="{{ route('printLaporan') }}" method="get">
                    @csrf
                    <div class="row align-items-center">
                <div class="col-3">
                    <input type="date" name="tanggal1" class="form-control">
                </div>
                <div class="col-3">
                    <input type="date" name="tanggal2" class="form-control">
                </div>
                <div class="col-6">
                    <button type="submit" class="btn btn-primary ion-printer"> Print PDF</button>
                </div>
                    </div>
                </div>
            
                
                {{-- <div class="d-flex justify-content-end mb-3">
                    <a href="{{ route('cetak', ['tanggal_awal' => app('request')->input('tanggal_awal'), 'tanggal_akhir' => app('request')->input('tanggal_akhir')]) }}" target="_blank" class="btn btn-primary" id="printButton">Print <i class="ion ion-printer"></i></a>
                </div>                 --}}
                <table class="table table-striped table-bordered" id="table_laporantransaksi">
                    <thead>
                        <tr>
                            <th class="text-center">KODE</th>
                            <th class="text-center">NAMA</th>
                            <th class="text-center">NAMA LAYANAN</th>
                            <th class="text-center">BERAT</th>
                            {{-- <th class="text-center">PANJANG</th> --}}
                            <th class="text-center">TOTAL</th>
                            <th class="text-center">NO.HP</th>
                            <th class="text-center">STATUS</th>
                            <th class="text-center">PEMBAYARAN</th>
                            <th class="text-center">TANGGAL MASUK</th>
                            <th class="text-center">TANGGAL KELUAR</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        {{-- Uncomment the following lines when you have data to display --}}
                        
                        @foreach($data as $transaksi)
                                <tr>
                                    <td class="text-center">{{ str_pad($transaksi->id, 4, '0', STR_PAD_LEFT) }}</td>
                                    <td class="text-center">{{ $transaksi->nama }}</td>
                                    <td class="text-center">
                                        @foreach ($transaksi->layanan_id as $lay)
                                            {{$lay->nama_layanan}}<br>
                                        @endforeach
                                    </td>
                                    <td class="text-center">
                                        @php
                                        $beratId = explode(',', $transaksi->berat);
                                        $berat = [];
                                        foreach ($beratId as $key => $value) {
                                            $berat[] = $value;
                                            echo $value.'<br>';
                                        }
                                        @endphp
                                    </td>
                                    <td class="text-center">
                                        @php
                                        $total = 0;
                                        foreach ($transaksi->layanan_id  as $key => $lay){
                                            $total += $lay->harga * $berat[$key];
                                        }
                
                                        echo number_format($total, 2); // Display total with 2 decimal places
                                        @endphp
                                    </td>
                                {{-- <td class="text-center">{{ $item->panjang }}</td> --}}
                                {{-- <td class="text-center">
                                    @php
                                    // Calculate total based on selected services
                                    $total = 0;
                                    foreach ($layanans as $layanan) {
                                        // Update perhitungan total berdasarkan harga dikali berat
                                        $total += $layanan->harga * $item->berat;
                                    }
                                    echo number_format($total, 2); // Display total with 2 decimal places
                                    @endphp
                                </td> --}}
                                <td class="text-center">{{ $transaksi->no_hp }}</td>
                                <td class="text-center">{{ $transaksi->status }}</td>
                                <td class="text-center">{{ $transaksi->pembayaran }}</td>
                                <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_masuk ))}}</td>
                                <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_keluar ))}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-center mt-3">
                    {{ $data->links('vendor.pagination.bootstrap-4') }}
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
