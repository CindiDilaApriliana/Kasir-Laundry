<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Transaksi</title>
    <style>
        @page {
            size: landscape;
        }
    </style>
</head>
<body>

@php
    // Initialize total variable
    $totalAmount = 0;
@endphp

<div class="card">
    <div class="card-body" align='center'>
        <h2>Data Transaksi</h2>           
        @if ($date && $date2)
            <h6>{{ $date }} - {{ $date2 }}</h6>
        @endif

        <div class="table-responsive mt-3">
            <table border="1" cellspacing="0" cellpadding="10" style="margin: auto;">
                <thead>
                    <tr>
                        <th class="text-center">KODE</th>
                        <th class="text-center">NAMA</th>
                        <th class="text-center">NAMA LAYANAN</th>
                        <th class="text-center">BERAT</th>
                        <th class="text-center">TOTAL</th>
                        <th class="text-center">NO.HP</th>
                        <th class="text-center">STATUS</th>
                        <th class="text-center">PEMBAYARAN</th>
                        <th class="text-center">TANGGAL MASUK</th>
                        <th class="text-center">TANGGAL KELUAR</th>
                    </tr>
                </thead>
                <tbody>
                    {{-- Uncomment the following lines when you have data to display --}}
                    @foreach($data as $transaksi)
                    <tr>
                        <td class="text-center">{{ str_pad($transaksi->id, 4, '0', STR_PAD_LEFT) }}</td>
                        <td class="text-center">{{ $transaksi->nama }}</td>
                        <td class="text-center">
                            @php
                    $layananId = explode(',', $transaksi->layanan_id);
                @endphp
                @foreach($layananId as $layananId)
                    @php
                        $layanan = \App\Models\Layanan::find($layananId);
                    @endphp
                    @if($layanan)
                            {{ $layanan->nama_layanan }}
                            <br>
                    @endif
                @endforeach
                        </td>
                        <td class="text-center">
                            @php
                            $beratId = explode(',', $transaksi->berat);
                            $berat = [];
                            foreach ($beratId as $key => $value) {
                                $berat[] = $value;
                                echo $value.'<br>';
                            }
                            @endphp
                        </td>
                        <td class="text-center">
                            @php
                            $total = 0;
                            $layanans = \App\Models\Layanan::whereIn('id', explode(',', $transaksi->layanan_id))->get();
                            foreach ($layanans as $key => $layanan) {
                                $total += $layanan->harga * $berat[$key];
                            }
                            echo number_format($total, 2);
                            @endphp
                            
                            @php
                            $totalAmount += $total;
                            @endphp 
                        </td>
                        <td class="text-center">{{ $transaksi->no_hp }}</td>
                        <td class="text-center">{{ $transaksi->status }}</td>
                        <td class="text-center">{{ $transaksi->pembayaran }}</td>
                        <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_masuk ))}}</td>
                        <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_keluar ))}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
        {{-- Display the total amount --}}
        <h3> Pendapatan Tanggal 
            @if ($date && $date2)
            {{ $date }} - {{ $date2 }}
            <br>
            Total    :     {{ number_format($totalAmount, 2) }}</h3>
        @endif 
</div>
</body>
</html>
