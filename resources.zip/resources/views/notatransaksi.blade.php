<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="/style.css">
    <title>Invoice</title>
    <style>
        /* Add your custom styles here */
        body {
    font-family: Arial, sans-serif;
}

.container {
    max-width: 800px;
    margin: 0 auto;
}

.logo {
    max-width: 100px;
    height: auto;
}


.company-name {
    font-size: 1.5em;
    font-weight: bold;
}

ul {
    list-style: none;
    padding: 0;
}

.flex-container {
    display: flex;
    justify-content: space-between;
}
table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        td.service-name {
    margin-bottom: 10px; /* Adjust this value as needed for spacing */
}

#cash {
            width: 60%; /* Adjust the width to your preference */
            padding: 8px; /* Add padding for better appearance */
            font-size: 14px; /* Adjust the font size for better readability */
        }
table, th, td {
    border: 1px solid black;
}

th, td {
    padding: 10px;
    text-align: center;
}

.font {
    font-size: 0.8em;
}


/* Print-specific styles */
@media print {
    body {
        font-size: 10pt; /* Adjust the font size for print */
    }

    .container {
        max-width: 100%;
        margin: ;
    }

    .logo {
        max-width: 80px; /* Adjust logo size for print */
    }

    .company-name {
        font-size: 1.2em; /* Adjust font size for print */
    }

    table {
        page-break-inside: auto; /* Avoid breaking tables across pages */
        border: none;
    }

    th, td {
        padding: 5px;
        border: none;
        
    }

    #cash {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border: none;
            /* Optional: Remove border if needed */
            outline: none;
            /* Optional: Remove outline if needed */
        }
        #printButton {
                display: none;
            }
            #Button {
                display: none;
            }


            @page {
                size: 80mm 327mm; /* Adjust the size according to your specific paper size */
                margin: 10mm; /* Adjust the margins as needed */
            }
        }
    </style>

    <div class="container">
        <div style="margin-bottom: 30px;">
            <img src="/img/logo.png" alt="Logo" class="logo">
            @foreach(\App\Models\Laundry::all() as $laundry)
                <h4 class="company-name">{{ $laundry->nama_laundry }}</h4>
                <ul>
                    <li>Alamat : {{ $laundry->alamat }}</li>
                    <li>Telp   : {{ $laundry->telp }}</li>
                </ul>
            @endforeach
            <hr>
            <div class="flex-container">
                <div class="left">
                    <ul>
                        <li>Nama :  {{ $transaksi->nama }}</li>
                        <li>Tanggal Masuk : {{ date('j-m-Y', strtotime($transaksi->tanggal_masuk ))}}</td></li>
                        <li>Tanggal Keluar : {{ date('j-m-Y', strtotime($transaksi->tanggal_keluar ))}}</td></li>
                        <li>No.Nota :  {{ str_pad($transaksi->id, 4, '0', STR_PAD_LEFT) }}</li>
                    </ul>
                </div>
            </div>
            <div class="right">
                <!-- Place your dynamic data here -->
            </div>
            <table>
                <thead>
                    <hr style="border-color: white;">
                    <tr>
                        <hr>
                        <th>Nama</th>
                        <th>Qyt</th>
                        <th>Harga Satuan</th>
                    </tr>
                </thead>
                
                <tbody>
                    
                    @php
                    // Calculate total based on selected services
                    $total = 0;
                    @endphp
                    @foreach($layanans as $layanan)
                        <tr>
                            <td>
                                @php
                    $layananId = explode(',', $transaksi->layanan_id);
                @endphp
                @foreach($layananId as $layananId)
                    @php
                        $layanan = \App\Models\Layanan::find($layananId);
                    @endphp
                    @if($layanan)
                            {{ $layanan->nama_layanan }}
                            <br>
                    @endif
                @endforeach
                            </td>
                                <td>
                                @php
                                $beratId = explode(',', $transaksi->berat);
                                $berat = [];
                                foreach ($beratId as $key => $value) {
                                    $berat[] = $value;
                                    echo $value.'<br>';
                                }
                                @endphp
                                </td>
                                <td>
                                    

                                    @php
                                        $layananId = explode(',', $transaksi->layanan_id);
                                    @endphp
                                    @foreach($layananId as $layananId)
                                        @php
                                            $layanan = \App\Models\Layanan::find($layananId);
                                        @endphp
                                        @if($layanan)
                                        {{ $layanan->harga }}
                                        <br>
                                        @endif
                                    @endforeach

                                    @php
                                    $layanan = \App\Models\Layanan::find($layananId);
                                    $beratId = explode(',', $transaksi->berat);
                                    $total += $layanan->harga * $berat[$key];
                                @endphp

                    @endforeach
                    {{-- <tr>
                        <td colspan="2" style="text-align: right;">Total:</td>
                        <td>{{ number_format($total, 2) }}</td>
                    </tr> --}}
                    {{-- <tr>
                        <td colspan="2" style="text-align: right;">Cash :</td>
                        <td>
                    <input type="text" id="cash" name="cash" class="form-control" placeholder="Enter cash amount"></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: right;">Kembalian :</td>
                        <td> <span id="change">0.00</span></td>
                    </tr> --}}
                </tr>
                </tbody>
            </table>
        </div>
        <hr>
        
        <div class="left">
            <div class="left"style="text-align: left">
                <label for="cash">Total : {{ number_format($total, 2) }}</label>
                <br>
                <label for="cash">Cash :</label>
                <input type="text" id="cash" name="cash" class="form-control" placeholder="0.00">
                <br>
                <label for="change">Kembalian :</label>
                <span id="change">0.00</span>
            </div>
    </div>
        <div class="flex-container">
            <p>Pembayaran : {{ $transaksi->pembayaran }}
            <button id="Button">
                @if($transaksi->pembayaran == 'Belum Bayar')
                <a href="{{route('update_pembayaran', $transaksi->id)}}" class="btn btn-primary">Belum Bayar</a>
                @else
                
                <a class="btn btn-success" disabled>Lunas</a>
                @endif
            </div>
            <hr>
        <div class="flex-container font">
            <div class="left">
                <ul>
                    <li> - Kerusakan/kehilangan baju diganti 3x</li>
                    <li> - Luntur/kerusakan tanpa pemberitahuan bukan tanggung jawab kami</li>
                    <li> - Barang tidak diambil selama 1 bulan, bukan tanggung jawab kami </li>
                    <li> - Komplain yang melebihi 2x24 jam setelah pengembalian tidak dilayani</li>
                </ul>
            </div>
        </div>
        <div class="flex-container">
        <button id="printButton">Print Invoice</button>
        {{-- <button>
            @if($transaksi->pembayaran == 'Belum Bayar')
            <a href="{{route('update_pembayaran', $transaksi->id)}}" class="btn btn-primary">Belum Bayar</a>
            @else
            
            <a class="btn btn-success" disabled>Lunas</a>
            @endif --}}
        </div>
    </div>
</body>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function () {
        // Function to calculate and display change
        function calculateChange() {
            // Get the cash amount entered by the user
            var cashAmount = parseFloat($("#cash").val()) || 0;

            // Calculate the change by subtracting the total from the cash amount
            var changeAmount = cashAmount - parseFloat("{{ $total }}");

            // Display the change in the span with id "change"
            $("#change").text(changeAmount.toFixed(2));
        }

        // Bind the function to the input event of the cash input field
        $("#cash").on("input", calculateChange);
    });
</script>

<script>
    $(document).ready(function () {
        // Your existing scripts

        // Function to handle the print button click
        $("#printButton").on("click", function () {
            // Trigger the browser's print dialog
            window.print();
        });
    });
</script>
</html>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
