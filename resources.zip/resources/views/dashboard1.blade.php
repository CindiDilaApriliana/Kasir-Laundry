<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laundry Dashboard</title>
        <link href="{{ asset('css/styles.css') }}" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body id="page-top">
    <nav class="navbar navbar-expand-lg navbar-primary bg-warning fixed-top " id="mainNav">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">ADINDA LAUNDRY</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto ">
                <a class="nav-link active" aria-current="page" href="#"></a>
                <a class="nav-link" href="#">Features</a>
                <a class="nav-link" href="#">Pricing</a>
                <a class="nav-link disabled" aria-disabled="true">Disabled</a>
            </div>
        </div>        
          </div>
        </div>
      </nav>

      <div class="row no-gutters ">
        <div class="col-md-2 bg-dark mt-5 pr-2 pt-4">
        <ul class="nav flex-column ms-3 mb-4">
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Dashboard</a><hr style="border-bottom: 1px solid rgb(121, 118, 118);"></li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#">Data Transaksi</a><hr style="border-bottom: 1px solid rgb(121, 118, 118);"></li>
            <li class="nav-item">
                <a class="nav-link text-white" href="#" >Laporan Transaksi</a><hr style="border-bottom: 1px solid rgb(121, 118, 118);"></li>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="#">Data Laundry</a><hr>
            </li>

          </ul>
      </div>
      <div class="col-md-10 mt-5 pr-2 pt-2">
        <h3> DASHBOARD</h3>
        <hr style="border-bottom: 1px solid rgb(121, 118, 118);">
    
        <div class="row">
            <div class="col-md-4">
                <div class="card bg-danger" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title text-white ms-8">DATA TRANSAKSI</h5>
                        <div class="display-4 text-white">1.200</div>
                        <p class="card-text text-white">Lihat Detail  >> <i class="fas fa-angle-double-right ms-2"></i></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title text-white ms-2">LAPORAN TRANSAKSI</h5>
                        <div class="display-4 text-white">1.200</div>
                        <p class="card-text text-white">Lihat Detail  >> <i class="fas fa-angle-double-right ms-2"></i></p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-primary" style="width: 18rem;">
                    <div class="card-body">
                        <h5 class="card-title text-white ms-8">DATA LAUNDRY</h5>
                        <div class="display-4 text-white">1.200</div>
                        <p class="card-text text-white">Lihat Detail  >> <i class="fas fa-angle-double-right ms-2"></i></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    </div>
    
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>
