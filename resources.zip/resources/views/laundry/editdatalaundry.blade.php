<!-- resources/views/admin/layanan/editlayanan.blade.php -->

@extends('layouts.main')

@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Edit Layanan</h1>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content-header -->

        <div class="modal-body">
            <div class="mt-3">
                <form action="{{ url('/laundry/editlaundry', $laundry->id) }}" method="POST">
                    @csrf
                    @method('PUT') <!-- Add this line to set the method to PUT -->
                    <div class="row">
                        <div class="form-group">
                            <label>Nama Laundry</label>
                            <input type="text" class="form-control" name="nama_laundry" id="name" value="{{ $laundry->nama_laundry }}">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            <label>Alamat</label>
                            <input type="text" class="form-control" name="alamat" id="alamat" value="{{ $laundry->alamat }}">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            <label>Telepon</label>
                            <input type="text" class="form-control" name="telp" id="telepon" value="{{ $laundry->telp }}">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <a href="{{ route('datalaundry') }}" class="btn btn-secondary">Close</a>
                        <button type="submit" class="btn btn-primary">Edit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
