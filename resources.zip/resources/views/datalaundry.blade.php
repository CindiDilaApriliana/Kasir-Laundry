@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Data Laundry</h1>
                </div>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
    <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
@endif
<div class="card">
    <div class="card-body">
        <div class="d-sm-flex justify-content-between align-items-center">
            <div>
                <!-- Konten lainnya -->
            </div>
            <div class="ml-auto">
                <div>
                    <div class="d-flex justify-content-end mb-3">
                        <div style="margin-left: 10px;"> <!-- Add margin to create space between buttons -->
                    </div>
                </div>
            </div>
        </div>
    </div>
        <div class="mt-3">
            {{-- <form class="forms-sample" action="{{ route('instansi.store') }}" method="POST"> --}}        
                <div class="row">
                    <div class="form-group">
                        <label>Nama Laundry</label>
                        @foreach(\App\Models\Laundry::all() as $laundry)
                        <input type="text" class="form-control" name="name" id="name" value="{{ $laundry->nama_laundry }}" disabled>
                        @endforeach
                    </div>
                </div>
                <div class="row">
                        <div class="form-group">
                            @foreach(\App\Models\Laundry::all() as $laundry)
                            <label>Alamat</label>
                            <input type="text" class="form-control" name="alamat" id="alamat" value="{{ $laundry->alamat}}" disabled>
                            @endforeach
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            @foreach(\App\Models\Laundry::all() as $laundry)
                            <label >Telepon</label>
                            <input type="text" class="form-control" name="telepon" id="telepon" value="{{ $laundry->telp }}" disabled>
                            @endforeach
                        </div>
                    </div>
                </div>
                <a href='/laundry/editdatalaundry/{{ $laundry->id }}'>
                <button type="button" class="btn btn-primary "  data-bs-toggle="modal" data-bs-target="#modalTambah">
                    Ubah Data  <i class="ion ion-edit"></i>
                  </button>
                    
                    </div>
                </div>
        </div>
    </div>
</div>
@endsection