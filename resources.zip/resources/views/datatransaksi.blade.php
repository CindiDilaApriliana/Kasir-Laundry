@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Data Transaksi</h1>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>

    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-between align-items-center">
                <div class="table-responsive">
                    <div class="mb-3">
                        <!-- Example in your Blade layout file -->
@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
@endif

                        <form action="{{ route('filter') }}" method="get">
                            @csrf
                            <div class="input-group w-50">
                                <input type="text" class="form-control" name="search" placeholder="Search...">
                                <button type="submit" class="btn btn-outline-secondary border ion ion-search"></button>
                            </div>
                        </form>
                    </div>
                    <div class="d-flex justify-content-end mb-3">
                        <button type="button" class="btn btn-primary me-2 ion-plus" data-bs-toggle="modal" data-bs-target="#modalTambah">
                            Tambah
                        </button>
                        @include('transaksi.tambahdata')
                        <a href='/datatransaksi'>
                            <button type="button" class="btn btn-primary ion-refresh" id="refreshButton"> Refresh </button>
                        </a>
                    </div>
                </div>
            </div>

            <div class="table-responsive mt-3 w-100">
                <table class="table table-striped table-bordered" id="table_datatransaksi">
                    <thead>
                        <tr>
                            <!-- Adjust these headers according to your data model -->
                            <th class="text-center px-5">KODE</th>
                            <th class="text-center">NAMA</th>
                            <th class="text-center">NAMA LAYANAN</th>
                            <th class="text-center">BERAT</th>
                            {{-- <th class="text-center">PANJANG</th> --}}
                            <th class="text-center">TOTAL</th>
                            <th class="text-center">STATUS</th>
                            <th class="text-center">PEMBAYARAN</th>
                            <th class="text-center">TANGGAL MASUK</th>
                            <th class="text-center">TANGGAL KELUAR</th>
                            <th class="text-center" width="135px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if(count($data) > 0)
                        @foreach($data as $transaksi)
                        <tr>
                            <td class="text-center">{{ str_pad($transaksi->id, 4, '0', STR_PAD_LEFT) }}</td>
                            <td class="text-center">{{ $transaksi->nama }}</td>
                            <td class="text-center">
                                @foreach ($transaksi->layanan_id as $layanan)
                                {{$layanan->nama_layanan}}<br>
                            @endforeach
                            
                            </td>
                            <td class="text-center">
                                @php
                                $beratId = explode(',', $transaksi->berat);
                                $berat = [];
                                foreach ($beratId as $key => $value) {
                                    $berat[] = $value;
                                    echo $value.'<br>';
                                }
                                @endphp
                            </td>
                            <td class="text-center">
                                @php
                                $total = 0;
                                foreach ($transaksi->layanan_id  as $key => $lay){
                                    $total += $lay->harga * $berat[$key];
                                }
        
                                echo number_format($total, 2); // Display total with 2 decimal places
                                @endphp
                            </td>
                            <td class="text-center">
                                @if($transaksi->status == 'Proses')
                                    <a href="{{route('update_status', $transaksi->id)}}" class="btn btn-primary">Proses</a>
                                @else
                                    <button class="btn btn-success" disabled>Selesai</button>
                                @endif
                                
                            </td>
                            <td class="text-center">
                                @if($transaksi->pembayaran == 'Belum Bayar')
                                    <a href="{{route('update_pembayaran', $transaksi->id)}}" class="btn btn-danger">Belum Bayar</a>
                                @else
                                    <button class="btn btn-success" disabled>Lunas</button>
                                @endif

                            </td>
                            <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_masuk ))}}</td>
                            <td class="text-center">{{ date('j-m-Y', strtotime($transaksi->tanggal_keluar ))}}</td>
                            <td class="text-center">
                                {{ $transaksi->aksi }}
                                <!-- Print button (assuming this triggers a print function) -->
                                <a href="notatransaksi/{{$transaksi->id}}" id="btn-show-spt" data-id="13" class="btn btn-warning btn-sm ion ion-printer"></a>
                                <!-- Edit button -->
                                <a href='/transaksi/editdatatransaksi/{{ $transaksi->id }}'>
                                    <button type="button" class="btn btn-success btn-sm ion ion-edit" data-bs-toggle="modal" data-bs-target="#modaledit" data-action="edit" data-id="{{ $transaksi->id }}"></button>
                                </a>
                                <form action="{{ route('deletetransaksi', $transaksi->id) }}" method="post" style="display: inline;">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm ion ion-trash-a" onclick="return confirm('Are you sure you want to delete this record?')"></button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                    
                </table>
                <div class="d-flex justify-content-center mt-3">
                    {{ $data->appends(request()->except('page'))->links('vendor.pagination.bootstrap-5') }}
                </div>

                @else
                    <p>No transactions found.</p>
                @endif
                </div>
            </div>
    </div>
</div>
</div>
</div>
@endsection
