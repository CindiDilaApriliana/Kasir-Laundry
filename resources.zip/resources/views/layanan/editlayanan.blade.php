<!-- resources/views/admin/layanan/editlayanan.blade.php -->

@extends('layouts.main')

@section('content')
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Edit Layanan</h1>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ url('/layanan/edit', $layanan->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nama_layanan">Nama Layanan</label>
                                    <input type="text" name="nama_layanan" class="form-control" value="{{ $layanan->nama_layanan }}">
                                </div>
                                <div class="form-group">
                                    <label for="harga">Harga</label>
                                    <input type="text" name="harga" class="form-control" onkeypress="return isNumber(event)" value="{{ $layanan->harga }}">
                                </div>
                            </div>
                            <div class="modal-footer text-center">
                                <a href="{{ route('datalayanan') }}" class="btn btn-secondary">Close</a>
                                <button type="submit" class="btn btn-primary">Edit Layanan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <script>
        function isNumber(event) {
            // Allow only numeric input and some special keys
            const charCode = event.which ? event.which : event.keyCode;

            if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 46 && charCode !== 8) {
                event.preventDefault();
                return false;
            }

            return true;
        }

        // Optional: You can add additional validation logic or use a library like jQuery Validation.
    </script>
    
@endsection
