<!-- resources/views/admin/layanan/createloyanan.blade.php -->

<div class="modal fade" id="modalLayanan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Layanan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('datalayanan') }}" method="POST" id="layananForm">
                @csrf
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nama Layanan</label>
                        <input type="text" name="nama_layanan" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="text" name="harga" id="harga" class="form-control" onkeypress="return isNumber(event)">
                    </div>
                </div>
                <div class="modal-footer text-center">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Tambah Layanan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function isNumber(event) {
        // Allow only numeric input and some special keys
        const charCode = event.which ? event.which : event.keyCode;

        if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode !== 46 && charCode !== 8) {
            event.preventDefault();
            return false;
        }

        return true;
    }

    // Optional: You can add additional validation logic or use a library like jQuery Validation.
</script>
