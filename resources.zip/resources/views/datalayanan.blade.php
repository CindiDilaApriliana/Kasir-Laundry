@extends('layouts.main')

@section('content')
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Data Transaksi</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="d-sm-flex justify-content-between align-items-center">
                <div class="table-responsive">
                    <div class="d-flex justify-content-end mb-3">
                        <button type="button" class="btn btn-primary ion-plus" data-bs-toggle="modal" data-bs-target="#modalLayanan">
                             Tambah
                        </button>
                        @include('layanan.tambahlayanan')
                    </div>
                </div>
            </div>

            <div class="table-responsive mt-10 w-100">
                @if(count($data) > 0)
                <table class="table table-striped table-bordered" id="table_datatransaksi">
                    <thead>
                        <tr>
                            <!-- Adjust these headers according to your data model -->
                            {{-- <th class="px-5 text-center">KODE</th> --}}
                            <th class="text-center">NAMA LAYANAN</th>
                            <th class="text-center">HARGA</th>
                            <th class="text-center" width="135px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $layanan)
                        <tr>
                            {{-- <td class="text-center">{{ $layanan->id }}</td> --}}
                            <td class="text-center">{{ $layanan->nama_layanan }}</td>
                            <td class="text-center">{{ $layanan->harga }}</td>
                            <td class="text-center">{{ $layanan->aksi }}
                                <!-- Edit button -->
                                <a href='/layanan/editlayanan/{{ $layanan->id }}'>
                                    <button type="button" class="btn btn-success btn-sm ion ion-edit" data-bs-toggle="modal" data-bs-target="#modaledit" data-action="edit" data-id="{{ $layanan->id }}"></button>
                                    {{-- @include('admin.editdatatransaksi') --}}
                                    <!-- Delete button -->
                                    <a href="deletedata/{{$layanan->id}}"> <button type="submit" class="btn btn-danger btn-sm ion ion-trash-a" onclick="return confirm('Are you sure you want to delete this record?')"></button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                <div class="d-flex justify-content-center mt-3">
                    {{ $data->links('vendor.pagination.bootstrap-4') }}
                </div>
                @else
                <p>No transactions found.</p>
                @endif
            </div>
            <script>

            </script>
        </div>
    </div>
</div>

@endsection
