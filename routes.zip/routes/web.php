<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DataLaundryController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LaporanTransaksiController;
use App\Http\Controllers\LayananLaundryController;
use App\Http\Controllers\TransaksiController;
use App\Http\Controllers\UpdateDataController;
use App\Models\LaporanTransaksi;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\SesiController;
use App\Models\Layanan;
use App\Models\Member;
use App\Models\Transaksi;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['guest'])->group(function () {
    // Rute untuk halaman login
    Route::get('/', [SesiController::class, 'index'])->name('login');
    Route::post('/', [SesiController::class, 'login']);
});

Route::get('/home', function () {
    return redirect('/admin/dashboard');
});

Route::middleware(['auth'])->group(function () {
    // Rute untuk halaman dashboard dan logout
    Route::get('/admin/dashboard', [DashboardController::class, 'dashboard'])->name('admin.dashboard');
    Route::post('/logout', [SesiController::class, 'logout'])->name('logout');
    // Route::get('/admin/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/pegawai/dashboard', [DashboardController::class, 'dashboard'])->name('pegawai.dashboard');

    //Dashoard
    // Route::get('/admin/dashboard', [DashboardController::class, 'index']);
    // Route::post('/logout', [SesiController::class, 'logout'])->name('logout');

    // Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
    // Route::get('/register', [AuthController::class, 'register'])->name('register');
    // Route::post('/register', [AuthController::class, 'registerPost'])->name('register');
    // Route::get('/login', [AuthController::class, 'login'])->name('login');
    // Route::post('/login', [AuthController::class, 'loginPost'])->name('login');
    // });

    // Route::group(['middleware' => 'auth'], function () {
    //     Route::get('/home', [HomeController::class, 'index']);
    //     Route::delete('/logout', [AuthController::class, 'logout'])->name('logout');
    // });
    // Route::get('admin/dashboard', function () {
    //     return view(('admin/dashboard'));
    // });

    // // Dashboard
    // Route::get('/admin', [DashboardController::class, 'index']);


    Route::get('/datatransaksi', [TransaksiController::class, 'getTransaksi'])->name('datatransaksi');
    // Route::get('/laporantransaksi', [LaporanTransaksiController::class, 'getTransaksi'])->name('laporantransaksi');
    Route::get('/laporan transaksi/laporantransaksipdf', [LaporanTransaksiController::class, 'show'])->name('cetak');
    Route::get('/datalaundry', [DataLaundryController::class, 'index'])->name('datalaundry');
    Route::get('/datalayanan', [LayananLaundryController::class, 'getLayanan'])->name('datalayanan');

    // Laporan Transaksi
    Route::get('/laporantransaksi', [TransaksiController::class, 'filter'])->name('laporantransaksi');


    // CRUD Transaksi
    Route::post('/datatransaksi', [TransaksiController::class, 'addData']);
    Route::get('/modaledit/{id}', [TransaksiController::class, 'modaledit']);
    Route::get('/transaksi/editdatatransaksi/{id}', [TransaksiController::class, 'editdatatransaksi']);
    Route::put('/transaksi/editdata/{id}', [TransaksiController::class, 'editdata']);
    Route::delete('/deletetransaksi/{id}', [TransaksiController::class, 'deletetransaksi'])->name('deletetransaksi');



    // transaksi
    Route::get('/transaksi/update_status/{id}', [TransaksiController::class, 'status'])->name('update_status');
    Route::get('/transaksi/update_pembayaran/{id}', [TransaksiController::class, 'status_pembayaran'])->name('update_pembayaran');
    Route::get('/datatransaksi/filter', [TransaksiController::class, 'filter'])->name('filter');
    Route::get('/searchmember', [TransaksiController::class, 'searchMember']);

    //CRUD Laundry
    Route::get('/laundry/editdatalaundry/{id}', [DataLaundryController::class, 'editdatalaundry']);
    Route::put('/laundry/editlaundry/{id}', [DataLaundryController::class, 'editlaundry']);
    Route::get('/datatransaksi/datalaundry', [DataLaundryController::class, 'index'])->name('datalaundry');

    // laporantransaksi
    Route::get('/laporantransaksi/filter', [LaporanTransaksiController::class, 'filterData'])->name('laporantransaksi.filter');
    Route::get('/laporantransaksi', [LaporanTransaksiController::class, 'getTransaksi'])->name('laporantransaksi');
    Route::get('/datatransaksi/laporantransaksi', [LaporanTransaksiController::class, 'getTransaksi'])->name('laporantransaksi');
    Route::get('/print-pdf', [LaporanTransaksiController::class, 'printPDF'])->name('printLaporan');
    Route::get('/laporantransaksi/pdf', [LaporanTransaksiController::class, 'printPDF'])->name('printLaporan');
    // Route::get('/delete-transaksi/{id}', [TransaksiController::class, 'deleteData'])->name('deleteData');

    //Invoice

    Route::get('/notatransaksi/{id}', [InvoiceController::class, 'generateInvoice']);
    Route::get('/datatransaksi/notatransaksi/{id}', [InvoiceController::class, 'generateInvoice']);
    Route::get('/notatransaksi', function () {
        return view(('/notatransaksi'));
    });
    Route::get('pegawai/notatransaksi/{id}', [InvoiceController::class, 'generateInvoice']);
    // Route::get('admin/notatransaksi/{id}', [InvoiceController::class, 'getInvoice'])->name('Invoice');


    // CRUD layanan laundry
    Route::post('/datalayanan', [LayananLaundryController::class, 'store']);
    // Route::get('/modaledit/{id}', [TransaksiController::class, 'modaledit']);
    Route::get('/layanan/editlayanan/{id}', [LayananLaundryController::class, 'editlayanan']);
    Route::put('/layanan/edit/{id}', [LayananLaundryController::class, 'edit']);
    Route::get('/deletedata/{id}', [LayananLaundryController::class, 'deletedata']);


    Route::get('/pegawai/dashboard', [DashboardController::class, 'dashboard'])->name('pegawai.dashboard');
    // Route::get('/pegawai/dashboard', [DashboardController::class, 'dashboard']);
    //     Route::get('/pegawai/datatransaksi', [TransaksiController::class, 'getTransaksi']);
    //     Route::get('/pegawai/datalaundry', [DataLaundryController::class, 'index']);
    //     Route::get('/pegawai/datalayanan', [LayananLaundryController::class, 'getLayanan']);
});
Route::group(['middleware' => ['checkRole:pegawai']], function () {
    Route::get('laporantransaksi', 'LaporanTransaksiController@index')->name('laporantransaksi');

    // Route::get('pegawai/notatransaksi/{id}', [InvoiceController::class, 'generateInvoice'])->name('update_pembayaran');
    Route::get('pegawai/notatransaksi', function () {
        return view(('pegawai/notatransaksi'));
    });
    // Add other routes that should be accessible only to 'pegawai' role
});
